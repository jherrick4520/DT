var dtv = {
	displayJoin:"s1",
	
	setup: function() {
		CF.log("dtv setup loaded");
	},

	keyPress: function(key,source) {
		CF.log("Changing image(" + source + ") to: " + key + ".png");
		//CF.setProperties({join: "d1", theme: btn_green_sqr_med});
		//CF.setProperties({join: "d2", theme: btn_red_sqr_med});
		//CF.setProperties({join: "d3", theme: btn_red_sqr_med});
		//CF.setProperties({join: "d"+(331+pos), theme: lightStatus[pos]=="Off"?"ButtonStd":"ButtonStd2"});
		CF.setJoin("s" + source, key + ".png");
		},

	RokuKeyPress: function(key) {
    		CF.log("RokuKey= " + key);
		CF.request("http://192.168.10.15:8060/keypress/" + key, "POST",{},"/keypress/" + key, function(status, headers, body) {
		CF.log("status="+status+",  body="+body);
    		});
		},

	RokuLoadApp: function(key,source) {
    		CF.log("RokuKey= " + key);
		CF.request("http://192.168.10.15:8060/launch/" + key, "POST",{},"/launch/" + key, function(status, headers, body) {
		CF.log("status="+status+",  body="+body);
    		});
		CF.setJoin("s8", source + ".png");
		},

	clearMatrix: function() {
		CF.log("Clear Matrix Inputs");	
		CF.setJoin("d101",0);
		CF.setJoin("d102",0);
		CF.setJoin("d103",0);
		CF.setJoin("d104",0);
		CF.setJoin("d105",0);
		CF.setJoin("d106",0);
		CF.setJoin("d107",0);
		CF.setJoin("d108",0);
		CF.setJoin("d109",0);
		CF.setJoin("d110",0);
		CF.setJoin("d111",0);
		CF.setJoin("d112",0);
		CF.setJoin("d113",0);
		CF.setJoin("d114",0);
		CF.setJoin("d115",0);
		CF.setJoin("d116",0);	
		},
	
	
	sourceSet: function(destination) {
		CF.log("Setting Destination : " + destination);
		},

};

CF.modules.push({
	name: "dtv",       // the name of the module (mostly for display purposes)
	setup: dtv.setup,  // the setup function to call
	object: dtv,       // the object to which the setup function belongs ("this")
	version: 1.0            // An optional module version number that is displayed in the Remote Debugger
});
